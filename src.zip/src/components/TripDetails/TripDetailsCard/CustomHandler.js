import React from 'react';
import {View} from 'react-native';

const CustomHandler = () => {
  return <View />;
};

export default CustomHandler;
