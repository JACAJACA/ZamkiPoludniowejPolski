import React from 'react';
import {Text, View} from 'react-native';

const FavoriteScreen = () => {
  return (
    <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
      <Text>Favorite</Text>
    </View>
  );
};

export default FavoriteScreen;
