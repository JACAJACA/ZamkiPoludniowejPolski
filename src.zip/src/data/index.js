const USERS = {
  1: {
    id: 1,
    username: 'Alexia Jane',
    avatar: require('../../assets/images/users/32.jpeg'),
  },
  2: {
    id: 2,
    username: 'Jacky Depp',
    avatar: require('../../assets/images/users/35.jpeg'),
  },
};

const REVIEWS = {
  1: {
    id: 1,
    date: '21 May, 2022',
    author: USERS[1],
    rating: 7,
    text: 'Lorem ipsum dolor sit amet. Iusto nihil et porro soluta ut labore nesciunt sed dolor nihil qui laudantium consequatur',
  },
  2: {
    id: 2,
    date: '14 July, 2021',
    author: USERS[2],
    rating: 9.1,
    text: 'Lorem ipsum dolor sit amet.',
  },
};

export const HOTELS = {
  1: {
    id: 1,
    title: 'Argos in Cappadocia',
    image: require('../../assets/images/hotels/cp-1.jpeg'),
    location: 'Turkey, Cappadocia',
    rating: 9,
    pricePeerDay: '130$',
    type: 'HOTEL',
  },
  2: {
    id: 2,
    title: 'Sultan Cave Suites',
    image: require('../../assets/images/hotels/cp-2.jpeg'),
    location: 'Turkey, Cappadocia',
    rating: 9.3,
    pricePeerDay: '230$',
    type: 'HOTEL',
  },
  3: {
    id: 3,
    title: 'Villa Brunella',
    image: require('../../assets/images/hotels/capri-1.jpeg'),
    location: 'Italy, Capri',
    rating: 9.4,
    pricePeerDay: '280$',
    type: 'HOTEL',
  },
  4: {
    id: 4,
    title: 'Hotel La Floridiana',
    image: require('../../assets/images/hotels/capri-2.jpeg'),
    location: 'Italy, Capri',
    rating: 9.3,
    pricePeerDay: '190$',
    type: 'HOTEL',
  },
  5: {
    id: 5,
    title: "Le Taha'a by Pearl Resorts",
    image: require('../../assets/images/hotels/polynesia-1.jpeg'),
    location: 'Polynesia, Bora Bora',
    rating: 9.2,
    pricePeerDay: '250$',
    type: 'HOTEL',
  },
  6: {
    id: 6,
    title: 'Le Meridien Bora Bora',
    image: require('../../assets/images/hotels/polynesia-2.jpeg'),
    location: 'Polynesia, Bora Bora',
    rating: 9.4,
    pricePeerDay: '270$',
    type: 'HOTEL',
  },
  7: {
    id: 7,
    title: 'InterContinental Phuket Resort',
    image: require('../../assets/images/hotels/phuket-1.jpg'),
    location: 'Thailand, Phuket',
    rating: 9.2,
    pricePeerDay: '210$',
    type: 'HOTEL',
  },
  8: {
    id: 8,
    title: 'The Nai Harn',
    image: require('../../assets/images/hotels/phuket-2.jpeg'),
    location: 'Thailand, Phuket',
    rating: 9.4,
    pricePeerDay: '430$',
    type: 'HOTEL',
  },
  9: {
    id: 9,
    title: 'Hotel Poseidon',
    image: require('../../assets/images/hotels/ac-1.jpeg'),
    location: 'Italy, Amalfi Coast',
    rating: 9.2,
    pricePeerDay: '330$',
    type: 'HOTEL',
  },
  10: {
    id: 10,
    title: 'Le Agavi Hotel',
    image: require('../../assets/images/hotels/ac-2.jpeg'),
    location: 'Italy, Amalfi Coast',
    rating: 9.4,
    pricePeerDay: '350$',
    type: 'HOTEL',
  },
  11: {
    id: 11,
    title: 'Hotel Casa 1800 Granada',
    image: require('../../assets/images/hotels/granada-1.jpeg'),
    location: 'Spain, Granada',
    rating: 9.2,
    pricePeerDay: '230$',
    type: 'HOTEL',
  },
  12: {
    id: 12,
    title: 'Parador de Granada',
    image: require('../../assets/images/hotels/granada-2.jpeg'),
    location: 'Spain, Granada',
    rating: 9.4,
    pricePeerDay: '120$',
    type: 'HOTEL',
  },

  13: {
    id: 13,
    title: 'Konansou',
    image: require('../../assets/images/hotels/cb-1.jpeg'),
    location: 'Japan, Cherry blossoms',
    rating: 9.2,
    pricePeerDay: '740$',
    type: 'HOTEL',
  },
  14: {
    id: 14,
    title: 'Shuhokaku Kogetsu',
    image: require('../../assets/images/hotels/cb-2.jpeg'),
    location: 'Japan, Cherry blossoms',
    rating: 9.4,
    pricePeerDay: '240$',
    type: 'HOTEL',
  },
};



export const PLACES = [
  {
    id: 1,
    image: require('../../assets/images/zamki/wisnicz3.jpg'),
    title: 'Zamek w Wiśniczu',
    location: 'Stary Wiśnicz',
    description:
      'Renesansowy zamek obronny położony w Starym Wiśniczu. Zamek wzniesiony w XIV wieku przez ród Kmitów, rozbudowany w XVII wieku przez Stanisława Lubomirskiego.',
    gallery: [
      require('../../assets/images/zamki/wisnicz2.jpg'),
      require('../../assets/images/zamki/wisnicz1.jpg'),
    ],
    type: 'PLACE',
    architecturalStyle: 'Renesansowy z elementami baroku',
    area: 'ok. 2500 m²',
    completed: 'XIV wiek',
    features: [
      'Bastion obronny',
      'Kaplica zamkowa',
      'Dziedziniec arkadowy'
    ],
    openingHours: '10:00 - 18:00',
    ticketPrices: {
      adults: '15 PLN',
      children: '8 PLN',
    },
    fullDescription:
      'Zamek w Starym Wiśniczu jest jednym z najlepiej zachowanych zamków renesansowych w Polsce. Wzniesiony przez rodzinę Kmitów w XIV wieku, został rozbudowany w stylu renesansowym w XVII wieku przez Stanisława Lubomirskiego. Obiekt pełnił funkcję zarówno rezydencji magnackiej, jak i obronnej twierdzy. Zamek otoczony jest bastionami, a wewnątrz znajduje się piękny dziedziniec arkadowy. W czasie potopu szwedzkiego został zniszczony, lecz jego główna struktura przetrwała do dziś. Obecnie zamek jest udostępniony dla zwiedzających, oferując liczne wystawy oraz wydarzenia kulturalne.',
  },
  {
    id: 2,
    image: require('../../assets/images/zamki/korzkiew1.jpg'),
    title: 'Zamek w Korzkwi',
    location: 'Korzkiew',
    description:
      'Mały zamek rycerski położony na Szlaku Orlich Gniazd, wzniesiony w XIV wieku. Obecnie pełni funkcję hotelu i centrum konferencyjnego.',
    gallery: [
      require('../../assets/images/zamki/korzkiew2.jpg'),
      require('../../assets/images/zamki/korzkiew3.jpg'),
    ],
    type: 'PLACE',
    architecturalStyle: 'Gotycki z elementami renesansu',
    area: 'ok. 1500 m²',
    completed: 'XIV wiek',
    features: [
      'Baszta obronna',
      'Dziedziniec wewnętrzny',
      'Malowniczy ogród'
    ],
    openingHours: 'Zwiedzanie na wcześniejsze zapisy',
    ticketPrices: {
      adults: '10 PLN',
      children: '5 PLN',
    },
    fullDescription:
      'Zamek w Korzkwi to niewielka, ale urokliwa budowla, będąca częścią Szlaku Orlich Gniazd. Zamek został wzniesiony w XIV wieku przez Jana z Syrokomli jako zamek obronny. W późniejszych wiekach był przebudowywany, co nadało mu elementy renesansowe. Obecnie zamek jest odrestaurowany i pełni funkcję hotelu oraz centrum konferencyjnego. Wokół zamku rozciąga się malowniczy ogród, a sam obiekt jest dostępny do zwiedzania po wcześniejszym umówieniu. Organizowane są tu również przyjęcia, wesela oraz inne wydarzenia kulturalne.',
  },
  {
    id: 3,
    image: require('../../assets/images/zamki/roznow1.jpg'),
    title: 'Zamek w Rożnowie',
    location: 'Rożnów',
    description:
      'Zamek obronny wzniesiony w XIV wieku przez rodzinę Rożnowskich, później przekształcony w rezydencję. Znany z położenia nad malowniczym Jeziorem Rożnowskim.',
    gallery: [
      require('../../assets/images/zamki/roznow2.jpg'),
    ],
    type: 'PLACE',
    architecturalStyle: 'Gotycko-renesansowy',
    area: 'ok. 2000 m²',
    completed: 'XIV wiek',
    features: [
      'Ruiny murów obronnych',
      'Wieża mieszkalna',
      'Widok na Jezioro Rożnowskie'
    ],
    openingHours: 'Całodobowo (teren dostępny do zwiedzania samodzielnego)',
    ticketPrices: {
      adults: 'Bez opłat',
      children: 'Bez opłat',
    },
    fullDescription:
      'Zamek w Rożnowie to zabytkowy zamek obronny z XIV wieku, zbudowany przez rodzinę Rożnowskich, a później rozbudowany przez hetmana Jana Tarnowskiego. Obiekt łączy w sobie elementy gotyku i renesansu, choć obecnie pozostały z niego ruiny. Teren zamku oferuje widok na malownicze Jezioro Rożnowskie, co czyni go popularnym miejscem wśród turystów i miłośników historii. Obecnie zamek znajduje się w stanie ruiny, ale można go swobodnie zwiedzać. W okolicy organizowane są wydarzenia kulturalne i historyczne, które przyciągają zarówno lokalnych mieszkańców, jak i przyjezdnych.',
  },
  {
    id: 4,
    image: require('../../assets/images/zamki/wawel1.jpg'),
    title: 'Zamek Królewski na Wawelu',
    location: 'Kraków',
    description:
      'Zabytkowy zamek obronno-rezydencyjny w Krakowie, na wzgórzu Wawelskim. Ma w nim siedzibę Państwowe Zbiory Sztuki – Zamek Królewski na Wawelu, muzeum o powierzchni 7040 m² z 71 salami wystawowymi.',
    gallery: [
      require('../../assets/images/zamki/wawel2.jpg'),
      require('../../assets/images/zamki/wawel3.jpg'),
    ],
    type: 'PLACE',

    architecturalStyle: 'Gotycki i Renesansowy',
    area: '7040 m²',
    completed: 'X wiek',
    features: [
      'Wieża Zygmuntowska', 
      'Kaplica Zygmuntowska', 
      'Smocza Jama'
    ],
    openingHours: '9:00 - 17:00',
    ticketPrices: {
      adults: '20 PLN',
      children: '10 PLN',
    },
    fullDescription:
      '',
  },
  {
    id: 5,
    image: require('../../assets/images/zamki/pieskowa_skala1.jpg'),
    title: 'Zamek Pieskowa Skała',
    location: 'Sułoszowa',
    description:
      'Renesansowy zamek położony w malowniczej Dolinie Prądnika, będący częścią Ojcowskiego Parku Narodowego. Jeden z najlepiej zachowanych zamków na Szlaku Orlich Gniazd.',
    gallery: [
      require('../../assets/images/zamki/pieskowa_skala2.jpg'),
      require('../../assets/images/zamki/pieskowa_skala3.jpg'),
    ],
    type: 'PLACE',
    architecturalStyle: 'Renesansowy',
    area: 'ok. 3000 m²',
    completed: 'XIV wiek',
    features: [
      'Dziedziniec arkadowy',
      'Baszta gotycka',
      'Kaplica zamkowa',
      'Widok na Maczugę Herkulesa'
    ],
    openingHours: '9:00 - 18:00 (sezon letni), 10:00 - 16:00 (sezon zimowy)',
    ticketPrices: {
      adults: '15 PLN',
      children: '10 PLN',
    },
    fullDescription:
      'Zamek Pieskowa Skała to perła renesansowej architektury, położona na terenie Ojcowskiego Parku Narodowego. Zamek został wzniesiony w XIV wieku z inicjatywy Kazimierza Wielkiego, a następnie przebudowany w stylu renesansowym przez rodzinę Szafrańców. Jego najbardziej charakterystycznym elementem jest dziedziniec arkadowy oraz wieża widokowa. Zamek pełnił funkcję rezydencji szlacheckiej oraz obronnej, a obecnie mieści muzeum, które prezentuje historię regionu oraz sztukę renesansową. W pobliżu zamku znajduje się słynna Maczuga Herkulesa – formacja skalna, będąca symbolem Doliny Prądnika. Obiekt jest popularnym miejscem turystycznym i jednym z kluczowych punktów Szlaku Orlich Gniazd.',
  },
  {
    id: 6,
    image: require('../../assets/images/zamki/ksiaz3.jpg'),
    title: 'Zamek Książ',
    location: 'Wałbrzych',
    description:
      'Największy zamek na Dolnym Śląsku i trzeci co do wielkości zamek w Polsce, malowniczo położony na terenie Książańskiego Parku Krajobrazowego.',
    gallery: [
      require('../../assets/images/zamki/ksiaz2.jpg'),
      require('../../assets/images/zamki/ksiaz1.jpg'),
    ],
    type: 'PLACE',
    architecturalStyle: 'Barokowy, z elementami renesansu i gotyku',
    area: '11 000 m²',
    completed: 'XIII wiek',
    features: [
      'Tarasy ogrodowe',
      'Sala Maksymiliana',
      'Podziemne tunele',
      'Wieża widokowa'
    ],
    openingHours: '9:00 - 18:00',
    ticketPrices: {
      adults: '40 PLN',
      children: '25 PLN',
    },
    fullDescription:
      'Zamek Książ to jedna z najważniejszych atrakcji turystycznych Dolnego Śląska. Jego historia sięga XIII wieku, kiedy został wzniesiony przez książąt piastowskich. Przez wieki pełnił funkcję rezydencji książęcej oraz obronnej. Podczas II wojny światowej zamek został przejęty przez nazistów, którzy rozpoczęli budowę podziemnych tuneli w ramach tajnego projektu Riese. Obecnie zamek zachwyca bogatymi wnętrzami, takimi jak Sala Maksymiliana, oraz malowniczymi tarasami ogrodowymi. Z wieży widokowej roztacza się spektakularny widok na okoliczne lasy Książańskiego Parku Krajobrazowego. Zamek Książ to miejsce pełne historii, tajemnic i piękna, które przyciąga turystów z całego świata.',
  },
  {
    id: 7,
    image: require('../../assets/images/zamki/ogrodzieniec1.jpg'),
    title: 'Zamek Ogrodzieniec',
    location: 'Podzamcze',
    description:
      'Ruiny majestatycznego zamku położonego na Jurze Krakowsko-Częstochowskiej, będącego częścią Szlaku Orlich Gniazd.',
    gallery: [
      require('../../assets/images/zamki/ogrodzieniec2.jpg'),
      require('../../assets/images/zamki/ogrodzieniec3.jpg'),
    ],
    type: 'PLACE',
    architecturalStyle: 'Gotycki z elementami renesansu',
    area: '5000 m²',
    completed: 'XIV wiek',
    features: [
      'Ruiny zamkowe',
      'Wieża widokowa',
      'Dziedziniec zamkowy',
      'Park miniatur w pobliżu'
    ],
    openingHours: '9:00 - 17:00',
    ticketPrices: {
      adults: '25 PLN',
      children: '15 PLN',
    },
    fullDescription:
      'Zamek Ogrodzieniec, położony na najwyższym wzniesieniu Jury Krakowsko-Częstochowskiej, to jeden z najbardziej rozpoznawalnych zamków w Polsce. Wybudowany w XIV wieku, pełnił funkcję obronną i rezydencjonalną. Obecnie jest częścią Szlaku Orlich Gniazd, łączącego zamki i warownie wzdłuż malowniczej jurajskiej scenerii. Ruiny zachwycają swoją monumentalnością, a z wieży widokowej można podziwiać przepiękną panoramę okolicy. Zamek jest także miejscem licznych wydarzeń kulturalnych, w tym turniejów rycerskich i pokazów historycznych. W pobliżu znajduje się park miniatur, który przedstawia wszystkie zamki Szlaku Orlich Gniazd w pomniejszonej skali.',
  },
];

export const TOP_PLACES = PLACES.filter(place => 
  [1, 5, 7].includes(place.id)
);

export const POPULAR = PLACES.filter(place => 
  [1, 2, 3, 6].includes(place.id)
);

export const SEARCH_PLACES = [...PLACES].map(item => ({
  ...item,
  id: Math.random().toString(),
}));

export const SEARCH_HOTELS = [...PLACES].map(item => ({
  ...item,
  id: Math.random().toString(),
}));

/*export const SEARCH_HOTELS = [...Object.values(HOTELS)].map(item => ({
  ...item,
  id: Math.random().toString(),
}));*/

export const SEARCH_ALL = [...SEARCH_PLACES, ...SEARCH_HOTELS];
